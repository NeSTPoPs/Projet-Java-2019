import java.awt.Component;
import java.awt.event.MouseListener;

import javax.swing.*;
import items.*;
import monde.*;
import outil.Souris;
import personnage.*;

public class TestGraphisme  {
	private static final int TAILLE_CASE=40;
	private static final int NB_CASES=20;
	private static Souris souris;
	
	public static void ajouterBoucle(Monde monde, String item, int iter)
	{
		for (int i = 0; i < iter; i++)
		{
			if (item == "Pomme")
				monde.ajouterItem(new Pomme());
			if (item == "Cassoulet")
				monde.ajouterItem(new Cassoulet());
			if (item == "Poubelle")
				monde.ajouterItem(new Poubelle());
			if (item == "Creature")
				monde.ajouterItem(new Creature());
		}
	}
	
	public static void main( String [ ] args ) throws InterruptedException {
			                                                  // Cr�ation fen�tre graphique et ses caract�ristiques
		JFrame f = new JFrame () ;
		f.setLocationRelativeTo(null) ;
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		
		
		                                                  // Cr�ation du monde (qui est un panneau )
		Monde m = new Monde(NB_CASES,TAILLE_CASE) ;
		Souris souris = new Souris(m) ; 
		f.addMouseListener( (MouseListener)souris);
		ajouterBoucle(m, "Poubelle", (int)(Math.random()*30+20));
		ajouterBoucle(m, "Pomme", (int)(Math.random()*30+20));
		ajouterBoucle(m, "Cassoulet", (int)(Math.random()*30+20));
		ajouterBoucle(m, "Creature", (int)(Math.random()*10+5));
		f.setContentPane (m) ;                            //Ajout du monde � la fen�tre
		f.pack () ;                                         // Adaptation de la fen�tre au panneau
		f.setVisible ( true ) ;
		Avatar jake=new Avatar ("Jake" ,79.5 ,m) ;          // ajoute Jake dans le monde
		Avatar mark=new Avatar ("Mark" ,89.5 ,m) ;
		m.ajouterItem(jake);
		m.ajouterItem(mark);
		for ( int i =0;i <10; i++) {
			Thread.sleep(1000) ;                          // Ralenti l�affichage
			souris.reinitialiser();
			//---------------------------DEPLACEMENT DE J1------------------------
			System.out.println(String.format("### D�placement de %s ###", jake.getNom()));
			while( ! (jake.seDeplacer( souris.getX(), souris.getY()-1 ) ) ) {
				Thread.sleep(1000) ;  
			}
			souris.reinitialiser();
			jake.rencontrerVoisins();
			m.repaint () ;                  // Redessine le graphique
			Thread.sleep(1000) ;
			//---------------------------DEPLACEMENT DE J2------------------------
			System.out.println(String.format("### D�placement de %s ###", mark.getNom()));
			while( ! (mark.seDeplacer( souris.getX(), souris.getY()-1 ) ) ) {
				Thread.sleep(1000) ;  
			}
			
			mark.rencontrerVoisins();
			m.repaint () ;                  // Redessine le graphique

                            
		}
		if (mark.course() < jake.course())
		{
			System.out.println(String.format("%s a parcouru plus de distance face � %s !",jake.getNom(),mark.getNom()));
		}
		else
		{
			System.out.println(String.format("%s a parcouru plus de distance face � %s !",mark.getNom(),jake.getNom()));
		}
	}



	
}
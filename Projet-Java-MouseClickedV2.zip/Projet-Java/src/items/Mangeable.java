package items;

public interface Mangeable {
	public double getPoids();
}
